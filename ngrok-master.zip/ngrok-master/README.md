# ngrok

Course URL: https://downloadly.net/2021/13/33602/02/complete-react-native-developer-in-2021-zero-to-mastery-with-hooks/16/?#/33602-zerotoma-212138044729.html

https://rapidgator.net/file/0126bb5d9bb8a13d96badc5ae903bf39

https://www.nulledbucket.com/agile-fundamentals-including-scrum-and-kanban-free-download/

ADOBE XD
1. https://www.file-upload.com/users/hossenrax/72592/adobe-xd-mega-course-user-expe%E2%80%A6 (Adobe XD Mega Course - User Experience Design course)
2. https://send.cm/z9f0abb2jvoa (Adobe XD for Web Design: Essential Principles for UI & UX)
3. https://uptobox.com/6hji6pn994mp (Adobe XD Masterclass UI Design)
4. https://downloadly.net/2020/24/14094/05/design-mobile-apps-ui%d8%8c-ux-prototyping-in-adobe-xd-ps/22/?#/14094-udemy-142139065829.html (Design Mobile Apps: UI, UX & Prototyping in Adobe XD & PS)


https://downloadly.net/2021/02/40942/05/tailwind-css-a-new-way-to-think-css/05/?#/40942-udemy-022206014111.html
